  $( function() {
    $( "#fromDate" ).datepicker();
	$( "#toDate").datepicker();
	var reactHandler = this; 
var listname = ["Leave%20_Balance","Attendance_Logs"];

var i=0;
 var itemArrays = {};

var feedPromises = [];
for (var index = 0; index < listname.length; index++){
    //start the process to get all the feeds and save their ajax promises into an array
    feedPromises.push(test(listname[index]));
}
function test(ListName) {
debugger;

  //alert("getfeed ")
  return  $.ajax({
    url: _spPageContextInfo.siteAbsoluteUrl+ "/_api/web/lists/getbytitle('" + ListName + "')/items?$top=5000" ,

    type: "GET", 

    headers:{'Accept': 'application/json; odata=verbose;'},

      success: function (resultData) {


              itemArrays[i] = resultData.d.results;

               ++i;

      }, 

  error : function(jqXHR, textStatus, errorThrown) { 

  }
  });
}
var listData;
var flag=true;
// wait until all the feeds return data to continue
$.when.apply(this, feedPromises)
.done(function(){
    // when all the data calls are successful you can access the data via
			if (itemArrays[0].length < 0) {
		//construct HTML Table from the JSON Data
		$('#CustomerGrid').append(GenerateTableFromJson(itemArrays));
		//Bind the HTML data with Jquery DataTable
		var oTable = $('#CustomerRecordsTable').dataTable({
		"iDisplayLength": 5,
		"aLengthMenu": [
		[5, 10, 30, 50],
		[5, 10, 30, 50]
		],
		"sPaginationType": "full_numbers"
		});
		} else {
		$('#CustomerGrid').append("<span>No Customer Records Found.</span>");
		}
   
});

 $("#btnSubmit").click(function(){
    //alert("The paragraph was clicked.");
     var value = $("#fromDate").val();
     var value1 = $("#toDate").val();
    if(value.length  == 0){
        alert("Please Select Satrt Date");
    }
    else if(value1.length == 0){
         alert("Please Select ToDate");
    }
    else{
	getEmployeeAttendence();
    }
});
  function getEmployeeAttendence(){
	//alert(itemArrays);
	$('#CustomerGrid').empty();
	
	// when all the data calls are successful you can access the data via
			if (itemArrays[0].length > 0) {
		//construct HTML Table from the JSON Data
		$('#CustomerGrid').append(GenerateTableFromJsonAttendance(itemArrays));
		//Bind the HTML data with Jquery DataTable
		var oTable = $('#CustomerRecordsTable').dataTable({
		"iDisplayLength": 5,
		"aLengthMenu": [
		[5, 10, 30, 50],
		[5, 10, 30, 50]
		],
		"sPaginationType": "full_numbers"
		});
		} else {
		$('#CustomerGrid').append("<span>No Customer Records Found.</span>");
		}
}
     
function GenerateTableFromJsonAttendance(objArray) {
	 
                    var tableContent = '<table id="CustomerRecordsTable" style="width:100%"><thead><tr><td>Employee_Id</td>' + '<td>PL</td>' + '<td>SL</td>'+ '<td>RemainingPL</td>'+ '<td>RemainingSL</td>'+ '<td>TotalTakenLeave</td>'+ '<td>TotalTakenPL</td>'+ '<td>TotalTakenSL</td>' + '</tr></thead><tbody>';
                    for (var i = 0; i < objArray[0].length; i++) {
                        var arr=[];
                        var arr1=[];
                        var arr2=[];
                        $.grep(objArray[1], function( n, k ) {
                         //   debugger;
                            //var fromdate1 = new Date($('#fromDate').val()).toLocaleDateString();
      //var todate1 =new Date($('#toDate').val()).toLocaleDateString();

                            if(objArray[0][i] && $.trim(objArray[0][i].User_Id) == $.trim(n.Employee_Id) && new Date(n.Attendance_Date).toLocaleDateString()>= new Date($('#fromDate').val()).toLocaleDateString() && new Date(n.Attendance_Date).toLocaleDateString()<= new Date($('#toDate').val()).toLocaleDateString() && n.Status =="Absent"){
                        
                        arr.push(n);
		}
        
}); 
 $.grep(objArray[1], function( n, k ) {
                            //debugger;
                            // var fromdate1 = new Date($('#fromDate').val()).toLocaleDateString();
     // var todate1 =new Date($('#toDate').val()).toLocaleDateString();
                            if(objArray[0][i] && $.trim(objArray[0][i].User_Id) == $.trim(n.Employee_Id) && new Date(n.Attendance_Date).toLocaleDateString()>=new Date($('#fromDate').val()).toLocaleDateString() && new Date(n.Attendance_Date).toLocaleDateString()<=new Date($('#toDate').val()).toLocaleDateString() && n.Status =="Absent" && n.Leave_x0020_Status == "PL"){
                 
                  
                        arr1.push(n);
		}
        
});
  $.grep(objArray[1], function( n, k ) {
                            //debugger;
                            // var fromdate1 = new Date($('#fromDate').val()).toLocaleDateString();
      //var todate1 =new Date($('#toDate').val()).toLocaleDateString();
                            if(objArray[0][i] && $.trim(objArray[0][i].User_Id) == $.trim(n.Employee_Id) && new Date(n.Attendance_Date).toLocaleDateString()>= new Date($('#fromDate').val()).toLocaleDateString() && new Date(n.Attendance_Date).toLocaleDateString()<= new Date($('#toDate').val()).toLocaleDateString() && n.Status == "Absent" && n.Leave_x0020_Status == "SL"){
                 
                        arr2.push(n);
		}
        
}); 
                  
if(arr.length>0 && arr1.length>0 && arr2.length>=0){
	  for (var j = 0; j<1; j++)
       {
           debugger;
        tableContent += '<tr>';
        tableContent += '<td>' + arr[j].Employee_Id + '</td>';
        tableContent += '<td>' + objArray[0][i].PL + '</td>';
       // tableContent += '<td>' + arr[j].Attendance_Date + '</td>';
        tableContent += '<td>' + objArray[0][i].SL + '</td>';
        tableContent += '<td>' +(parseInt('20')-parseInt(objArray[0][i].PL)) + '</td>';
        tableContent += '<td>'+(parseInt('20')-parseInt(objArray[0][i].SL))+ '</td>';
        tableContent += '<td>' + arr.length + '</td>';
        tableContent += '<td>' + arr1.length + '</td>';
         tableContent += '<td>' + arr2.length + '</td>';
      //  alert(tableContent += '<td>' + arr2.length + '</td>');
        tableContent += '</tr>';
	  }
    }
 }
 return tableContent;
 }
  } );
 function fnExcelReport()
{debugger;
    var tab_text="<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j=0;
    tab = document.getElementById('CustomerRecordsTable'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}

